"use client";

// src/app/components/Header.tsx
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";

const NAV_LINKS = [
  { href: "/", label: "Calculator" },
  { href: "/salariu-minim", label: "Salariu minim" },
  { href: "/salariu-mediu", label: "Salariu mediu" },
];

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [prevPathname, setPrevPathname] = useState(pathname);

  if (pathname !== prevPathname) {
    setPrevPathname(pathname);
    if (open) setOpen(false);
  }

  const isActive = (href: string) => {
    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  };

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const desktopLink = (active: boolean) =>
    `flex items-center rounded-md px-3 text-sm transition-colors duration-100 hover:bg-slate-100 ${
      active ? "font-semibold text-emerald-700" : "font-medium text-slate-600"
    }`;

  const mobileLink = (active: boolean) =>
    `block min-h-12 px-4 py-3 text-base border-b border-slate-100 last:border-b-0 ${
      active ? "font-semibold bg-emerald-50 text-emerald-700" : "text-slate-700"
    }`;

  const bar = "block h-0.5 w-5 bg-slate-900 transition duration-[250ms]";

  return (
    <>
      {/* HEADER — bară albă curată, lipită sus, cu hairline jos. */}
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-2 px-4 sm:px-6">
          <Link
            href="/"
            className="mr-auto text-xl font-extrabold tracking-tight text-slate-900"
          >
            salariile<span className="text-emerald-600">.ro</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden h-full items-center gap-1 md:flex">
            {NAV_LINKS.map((link) => (
              <Link key={link.href} href={link.href} className={desktopLink(isActive(link.href))}>
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Mobile hamburger button */}
          <button
            className="ml-auto flex h-11 w-11 cursor-pointer flex-col items-center justify-center gap-[5px] rounded-md p-0 hover:bg-slate-100 md:hidden"
            aria-label={open ? "Închide meniul" : "Deschide meniul"}
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            <span className={`${bar} ${open ? "translate-y-[7px] rotate-45" : ""}`} />
            <span className={`${bar} ${open ? "opacity-0" : ""}`} />
            <span className={`${bar} ${open ? "-translate-y-[7px] -rotate-45" : ""}`} />
          </button>
        </div>

        {/* Mobile dropdown */}
        <nav
          className={`${
            open ? "flex" : "hidden"
          } flex-col border-t border-slate-200 bg-white md:hidden`}
        >
          {NAV_LINKS.map((link) => (
            <Link key={link.href} href={link.href} className={mobileLink(isActive(link.href))}>
              {link.label}
            </Link>
          ))}
        </nav>
      </header>
    </>
  );
}
