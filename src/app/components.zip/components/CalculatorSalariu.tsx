"use client";

import React, { useState, useCallback } from "react";
import Link from "next/link";
import {
  calculeaza,
  calculeazaBrutDinNet,
  SALARIU_MINIM,
  DEDUCERE_MINIM,
  type InputState,
  type Rezultat,
} from "@/lib/fiscal";

type SelectOption = { v: number; l: string };

type InputNumberProps = {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  hint?: string;
};

type ToggleProps = {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
};

type SelectProps = {
  id: string;
  label: string;
  value: number;
  options: SelectOption[];
  onChange: (v: number) => void;
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

const fmt = (n: number) => new Intl.NumberFormat("ro-RO").format(n) + " lei";

// Construiește rezultatul afișat dintr-un snapshot de input + mod.
// Calculul se face O DATĂ, la momentul click pe Calculează — nu la fiecare render.
// Conține tot ce e nevoie să randeze tabelul + payload-ul PDF.
function buildResult(snapshotInput: InputState, snapshotMod: "brut" | "net") {
  const brutEfectiv = snapshotMod === "net"
    ? String(calculeazaBrutDinNet(parseFloat(snapshotInput.brut) || 0, snapshotInput))
    : snapshotInput.brut;
  const rez = calculeaza({ ...snapshotInput, brut: brutEfectiv });
  if (!rez) return null;
  return {
    rez,
    brutEfectiv,
    functieDeBAza: snapshotInput.functieDeBAza,
  };
}

// ─── Componente UI ────────────────────────────────────────────────────────────

// ─── Clase utilitare reutilizate (design tokens „în linie") ──────────────────
const fieldLabel =
  "mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500";
const controlBox =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition-colors focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500";

// Celule tabel-fluturaș
const cellL = "border-b border-slate-100 px-3 py-2.5 text-left";
const cellR = "border-b border-slate-100 px-3 py-2.5 text-right tabular-nums";
const colHeader =
  "mb-4 border-b border-slate-200 pb-2 text-lg font-semibold text-slate-900";

// Am adăugat 'id' în paranteze și am legat label-ul de input
function InputNumber({ id, label, value, onChange, placeholder, hint }: InputNumberProps) {
  return (
    <div className="mb-5">
      <label htmlFor={id} className={fieldLabel}>{label}</label>
      {hint && <span className="mb-1 block text-xs text-slate-400">{hint}</span>}
      <div className="flex w-full overflow-hidden rounded-lg border border-slate-300 transition-colors focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500">
        <input
          id={id}
          name={id}
          type="number"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder || "0"}
          min="0"
          className="min-w-0 flex-1 bg-transparent px-3 py-2.5 text-base text-slate-900 outline-none"
        />
        <span className="flex items-center whitespace-nowrap border-l border-slate-200 px-3 text-xs font-medium uppercase text-slate-400">
          LEI / lună
        </span>
      </div>
    </div>
  );
}

function Toggle({ label, checked, onChange }: ToggleProps) {
  return (
    <label className="flex min-h-11 cursor-pointer items-center justify-between border-b border-slate-100 py-3 text-sm text-slate-700 last:border-b-0">
      <span>{label}</span>
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        type="button"
        className={`relative h-6 w-11 flex-shrink-0 rounded-full transition-colors ${
          checked ? "bg-emerald-600" : "bg-slate-300"
        }`}
      >
        <span
          className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
            checked ? "translate-x-5" : ""
          }`}
        />
      </button>
    </label>
  );
}

function Select({ id, label, value, options, onChange }: SelectProps) {
  return (
    <div className="mb-5">
      <label htmlFor={id} className={fieldLabel}>{label}</label>
      <select id={id} value={value} onChange={(e) => onChange(Number(e.target.value))} className={`${controlBox} cursor-pointer`}>
        {options.map((o) => (<option key={o.v} value={o.v}>{o.l}</option>))}
      </select>
    </div>
  );
}

// ─── Generare PDF Fluturaș (format SAGA C) ───────────────────────────────────

// Helper: înlocuiește diacriticele românești cu echivalente fără diacritice
// (necesar pentru că fontul Helvetica default din jsPDF nu suportă Unicode complet)
function fixDiacritice(text: string): string {
  return text
    .replace(/ă/g, "a").replace(/Ă/g, "A")
    .replace(/â/g, "a").replace(/Â/g, "A")
    .replace(/î/g, "i").replace(/Î/g, "I")
    .replace(/ș/g, "s").replace(/Ș/g, "S")
    .replace(/ş/g, "s").replace(/Ş/g, "S")
    .replace(/ț/g, "t").replace(/Ț/g, "T")
    .replace(/ţ/g, "t").replace(/Ţ/g, "T");
}

async function generarePDFFluturas(
  brut: number,
  rez: Rezultat,
  esteSalariuMinim: boolean,
  facilitate: number
): Promise<void> {
  // Import dinamic — biblioteca se încarcă doar când utilizatorul apasă butonul
  const { jsPDF } = await import("jspdf");

  const doc = new jsPDF({ unit: "mm", format: "a4" });

  // Dimensiuni pagină
  const pageWidth = 210;
  const margin = 20;
  const colRight = pageWidth - margin; // 190 mm

  // Helper: scrie text (cu fix diacritice automat)
  const T = (
    text: string,
    x: number,
    y: number,
    opts?: { align?: "left" | "center" | "right" | "justify" }
  ) => {
    doc.text(fixDiacritice(text), x, y, opts);
  };

  // Helper pentru linii orizontale
  const linie = (y: number, gros = 0.2) => {
    doc.setLineWidth(gros);
    doc.line(margin, y, colRight, y);
  };

  // Helper pentru rând (label stânga + valoare dreapta)
  const rand = (y: number, label: string, valoare: string, bold = false, indent = 0) => {
    doc.setFont("helvetica", bold ? "bold" : "normal");
    T(label, margin + indent, y);
    T(valoare, colRight, y, { align: "right" });
  };

  let y = margin;

  // ─── Header firmă ─────────────────────────────────────
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  T("Calculator generat de salariile.ro", margin, y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  T("HG 146/2026 · OUG 89/2025", colRight, y, { align: "right" });
  y += 5;
  doc.setFontSize(8);
  T("Salariu calculat conform legislatiei fiscale 2026", margin, y);
  y += 8;

  linie(y, 0.5);
  y += 8;

  // ─── Titlu document ─────────────────────────────────────
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  T("FLUTURAS SALARIU", pageWidth / 2, y, { align: "center" });
  y += 6;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  const luna = new Date().toLocaleDateString("ro-RO", { month: "long", year: "numeric" });
  T(`Luna: ${luna.charAt(0).toUpperCase() + luna.slice(1)}`, pageWidth / 2, y, { align: "center" });
  y += 10;

  linie(y);
  y += 8;

  // ─── Linii de calcul (Venituri) ─────────────────────────────────────
  doc.setFontSize(10);

  // Salariu brut
  rand(y, "Salariu brut:", `${brut.toLocaleString("ro-RO")} lei`);
  y += 7;

  // Facilitate (doar dacă se aplică)
  if (esteSalariuMinim && facilitate > 0) {
    doc.setTextColor(80);
    rand(y, "Facilitate fiscala (neimpozabila):", `${facilitate} lei`);
    doc.setTextColor(0);
    y += 7;
  }

  y += 2;
  linie(y);
  y += 8;

  // ─── Rețineri (header secțiune) ─────────────────────────────────────
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  T("RETINERI", margin, y);
  y += 7;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);

  // CAS
  rand(y, "C.A.S. (Asigurari Sociale - 25%)", `- ${rez.cas.toLocaleString("ro-RO")} lei`, false, 5);
  y += 6;

  // CASS
  rand(y, "C.A.S.S. (Asigurari Sanatate - 10%)", `- ${rez.cass.toLocaleString("ro-RO")} lei`, false, 5);
  y += 6;

  // Deducere personală (informativ — text gri)
  if (rez.deducerePersonala > 0) {
    doc.setTextColor(100);
    rand(y, "Deducere personala", `${rez.deducerePersonala.toLocaleString("ro-RO")} lei`, false, 5);
    doc.setTextColor(0);
    y += 6;
  }

  // Impozit
  rand(y, "Impozit pe venit (10%)", `- ${rez.impozit.toLocaleString("ro-RO")} lei`, false, 5);
  y += 8;

  linie(y);
  y += 7;

  // Total rețineri
  doc.setFontSize(10);
  rand(y, "Total Retineri Angajat:", `${(rez.cas + rez.cass + rez.impozit).toLocaleString("ro-RO")} lei`, true);
  y += 9;

  // Salariu net (mare)
  doc.setFontSize(13);
  rand(y, "SALARIU NET:", `${rez.net.toLocaleString("ro-RO")} lei`, true);
  y += 8;

  linie(y, 0.5);
  y += 10;

  // ─── Cost angajator ─────────────────────────────────────
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  T("COST ANGAJATOR", margin, y);
  y += 7;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  rand(y, "C.A.M. (Contributie Munca - 2,25%)", `${rez.cam.toLocaleString("ro-RO")} lei`, false, 5);
  y += 6;
  rand(y, "Cost total firma:", `${rez.costTotal.toLocaleString("ro-RO")} lei`, true);
  y += 14;

  linie(y, 0.2);
  y += 5;

  // ─── Footer ─────────────────────────────────────
  doc.setFontSize(7);
  doc.setFont("helvetica", "italic");
  doc.setTextColor(120);
  T("Document generat de salariile.ro · Calcul informativ, conform legislatiei fiscale in vigoare", pageWidth / 2, y, { align: "center" });
  y += 4;
  T(`Generat la ${new Date().toLocaleString("ro-RO")}`, pageWidth / 2, y, { align: "center" });

  // Salvare
  const numefisier = `fluturas-salariu-${brut}-lei.pdf`;
  doc.save(numefisier);
}

// ─── Componenta principală (ACUM ACCEPTĂ PROPS DINAMICE) ──────────────────────

export default function CalculatorSalariu({
  brutInitial = "",
  modInitial = "brut",
  titluCustom,
  subtitluCustom,
}: {
  brutInitial?: string;
  modInitial?: "brut" | "net";
  titluCustom?: React.ReactNode;
  subtitluCustom?: React.ReactNode;
}) {
  const [mod, setMod] = useState<"brut" | "net">(modInitial);
  const [avansat, setAvansat] = useState(false);

  const initialInput: InputState = {
    brut: brutInitial,
    tichete: "",
    functieDeBAza: true,
    persoanePretretinere: 0,
    varstaSub26: false,
    copiiScolarizati: 0,
    scutitImpozit: false,
  };

  const [input, setInput] = useState<InputState>(initialInput);

  // Rezultatul afișat — calculat O DATĂ la click pe Calculează, stocat ca obiect.
  // Nu se schimbă la tastare/toggle, doar la click. La mount, dacă brutInitial
  // e prezent (pagini dinamice tip /4050-brut-...), pre-calculează (auto-commit
  // pentru SEO/SSR — Google vede tabelul completat la randare).
  const [rezAfisat, setRezAfisat] = useState<ReturnType<typeof buildResult>>(
    brutInitial && parseFloat(brutInitial) > 0 ? buildResult(initialInput, modInitial) : null
  );

  const set = useCallback(
    <K extends keyof InputState>(k: K, v: InputState[K]) =>
      setInput((p) => ({ ...p, [k]: v })),
    []
  );

  return (
    <>
      {/* ── Hero ── */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
          {/* Breadcrumb doar pe pagini dinamice, nu pe homepage */}
          {titluCustom && (
            <nav className="mb-4 flex gap-2 text-xs uppercase tracking-wide text-slate-400" aria-label="Breadcrumb">
              <Link href="/" className="hover:text-slate-700">Acasă</Link>
              <span>/</span>
              <span aria-current="page">Calculator salariu</span>
            </nav>
          )}

          {/* Titlul Dinamic */}
          <h1 className="mb-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
            {titluCustom || <>Calculator salariu net 2026</>}
          </h1>

          {/* Subtitlul Dinamic */}
          <p className="max-w-2xl text-base leading-relaxed text-slate-600 [&_a]:font-medium [&_a]:text-emerald-700 [&_a]:underline [&_a]:underline-offset-2 hover:[&_a]:text-emerald-800">
            {subtitluCustom || (
              <>
                Calculează salariul net din brut. CAS, CASS, impozit și cost angajator — actualizat conform{" "}
                <a href="https://legislatie.just.ro/Public/DetaliiDocument/308231" target="_blank" rel="noopener noreferrer">HG 146/2026</a>
                {" "}și{" "}
                <a href="https://legislatie.just.ro/Public/DetaliiDocument/305817" target="_blank" rel="noopener noreferrer">OUG 89/2025</a>.
              </>
            )}
          </p>

          {/* Dateline tehnic, scurt și curat */}
          {!titluCustom && (
            <div className="mt-4 text-xs uppercase tracking-wide text-slate-400">
              Ultima actualizare: 30 aprilie 2026 · Sincronizat cu Declarația 112 ANAF
            </div>
          )}
        </div>
      </section>

      {/* ── Calculator ── */}
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:px-6 md:grid-cols-5" id="calc-layout">
        {/* Coloana Stângă — formular */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6 md:col-span-2" data-md-strip>
          <h2 className={colHeader}>Date salariale</h2>

          <div className="mb-5">
            <span className={fieldLabel}>Direcție de calcul</span>
            <div className="inline-flex overflow-hidden rounded-lg border border-slate-300">
              <button
                type="button"
                className={`min-h-11 px-4 py-2.5 text-sm font-medium transition-colors ${mod === "brut" ? "bg-emerald-600 text-white" : "text-slate-500 hover:bg-slate-50"}`}
                onClick={() => {
                  if (mod === "net") {
                    const netVal = parseFloat(input.brut) || 0;
                    set("brut", String(calculeazaBrutDinNet(netVal, input)));
                  }
                  setMod("brut");
                }}
              >
                Din brut în net
              </button>
              <button
                type="button"
                className={`min-h-11 border-l border-slate-300 px-4 py-2.5 text-sm font-medium transition-colors ${mod === "net" ? "bg-emerald-600 text-white" : "text-slate-500 hover:bg-slate-50"}`}
                onClick={() => {
                  if (mod === "brut") {
                    const rezTemp = calculeaza(input);
                    if (rezTemp) set("brut", String(rezTemp.net));
                  }
                  setMod("net");
                }}
              >
                Din net în brut
              </button>
            </div>
          </div>

          <InputNumber id="salariu-input" label={mod === "brut" ? "SALARIU BRUT:" : "SALARIU NET:"} value={input.brut} onChange={(v) => set("brut", v)} />

          <button
            type="button"
            className="mb-4 w-full rounded-lg border border-dashed border-slate-300 px-3 py-2.5 text-xs font-medium uppercase tracking-wide text-slate-500 transition-colors hover:border-slate-400 hover:text-slate-700"
            onClick={() => {
              if (avansat) { set("tichete", ""); set("functieDeBAza", true); set("persoanePretretinere", 0); set("varstaSub26", false); set("copiiScolarizati", 0); set("scutitImpozit", false); }
              setAvansat(!avansat);
            }}
          >
            {avansat ? "▲ Ascunde opțiuni avansate" : "▼ Calculator avansat"}
          </button>

          {avansat && (
            <>
              <InputNumber id="tichete-input" label="Tichete de masă" value={input.tichete} onChange={(v) => set("tichete", v)} placeholder="0" hint="Valoare lunară totală" />
              <Toggle label="Funcție de bază" checked={input.functieDeBAza} onChange={(v) => set("functieDeBAza", v)} />
              <Select id="persoane-intretinere" label="Persoane în întreținere" value={input.persoanePretretinere} options={[0, 1, 2, 3, 4].map((n) => ({ v: n, l: n === 0 ? "Niciuna" : `${n} ${n === 1 ? "persoană" : "persoane"}` }))} onChange={(v) => set("persoanePretretinere", v)} />
              <Select id="copii-scolari" label="Copii minori școlari" value={input.copiiScolarizati} options={[0, 1, 2, 3, 4, 5].map((n) => ({ v: n, l: n === 0 ? "Niciunul" : `${n} ${n === 1 ? "copil" : "copii"}` }))} onChange={(v) => set("copiiScolarizati", v)} />
              <Toggle label="Vârstă sub 26 ani" checked={input.varstaSub26} onChange={(v) => set("varstaSub26", v)} />
              <Toggle label="Scutit de impozit (handicap etc.)" checked={input.scutitImpozit} onChange={(v) => set("scutitImpozit", v)} />
            </>
          )}

          <button
            type="button"
            className="mt-2 block min-h-12 w-full rounded-lg bg-emerald-600 px-4 py-3 text-sm font-semibold uppercase tracking-wide text-white shadow-sm transition-colors hover:bg-emerald-700 active:translate-y-px"
            onClick={() => {
              // 1) Calculează O DATĂ și stochează direct rezultatul.
              setRezAfisat(buildResult(input, mod));
              // 2) Scroll la zona corectă (mobile: results-col; desktop: calc-layout).
              if (typeof window === "undefined") return;
              const isMobile = window.matchMedia("(max-width: 768px)").matches;
              const targetId = isMobile ? "rezultat-calcul" : "calc-layout";
              document.getElementById(targetId)?.scrollIntoView({ behavior: "smooth", block: "start" });
            }}
            aria-label="Calculează salariul și navighează la rezultat"
          >
            Calculează
          </button>
        </div>

        {/* Coloana Dreaptă — rezultate */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6 md:col-span-3" id="rezultat-calcul">
          <h2 className={colHeader}>Rezultat calcul</h2>

          {rezAfisat ? (
            <div className="overflow-hidden rounded-lg border border-slate-200">
              <table className="w-full border-collapse text-sm text-slate-700">
                <thead>
                  <tr>
                    <th className="border-b border-slate-300 bg-slate-100 px-3 py-2.5 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Indicator Fiscal</th>
                    <th className="border-b border-slate-300 bg-slate-100 px-3 py-2.5 text-right text-xs font-bold uppercase tracking-wide text-slate-500">Sumă</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className={`${cellL} font-medium text-slate-900`}>Salariu de încadrare (Brut)</td>
                    <td className={`${cellR} font-medium text-slate-900`}>{fmt(parseFloat(rezAfisat.brutEfectiv))}</td>
                  </tr>
                  {parseFloat(rezAfisat.brutEfectiv) === SALARIU_MINIM && rezAfisat.functieDeBAza && (
                    <tr>
                      <td className={`${cellL} pl-8 text-slate-500`}>Facilitate fiscală (neimpozabilă)</td>
                      <td className={cellR}>{fmt(DEDUCERE_MINIM)}</td>
                    </tr>
                  )}
                  <tr>
                    <td className={`${cellL} pl-8 text-slate-500`}>CAS (Pensii - 25%)</td>
                    <td className={cellR}>− {fmt(rezAfisat.rez.cas)}</td>
                  </tr>
                  <tr>
                    <td className={`${cellL} pl-8 text-slate-500`}>CASS (Sănătate - 10%)</td>
                    <td className={cellR}>− {fmt(rezAfisat.rez.cass)}</td>
                  </tr>
                  {rezAfisat.rez.deducerePersonala > 0 && (
                    <tr>
                      <td className={`${cellL} pl-8 text-slate-500`}>Deducere personală (aplicată)</td>
                      <td className={cellR}>{fmt(rezAfisat.rez.deducerePersonala)}</td>
                    </tr>
                  )}
                  <tr>
                    <td className={cellL}>Impozit pe venit (10%)</td>
                    <td className={cellR}>− {fmt(rezAfisat.rez.impozit)}</td>
                  </tr>
                  <tr className="bg-slate-50">
                    <td className={`${cellL} font-semibold text-slate-900`}>Total Rețineri Angajat</td>
                    <td className={`${cellR} font-semibold text-slate-900`}>{fmt(rezAfisat.rez.cas + rezAfisat.rez.cass + rezAfisat.rez.impozit)}</td>
                  </tr>
                  <tr className="bg-emerald-600">
                    <td className="px-3 py-3 text-left text-sm font-bold uppercase tracking-wide text-white">SALARIU NET</td>
                    <td className="px-3 py-3 text-right text-base font-bold tabular-nums text-white">{fmt(rezAfisat.rez.net)}</td>
                  </tr>
                </tbody>
                <tbody>
                  <tr aria-hidden="true"><td colSpan={2} className="h-4 p-0" /></tr>
                </tbody>
                <tbody>
                  <tr>
                    <td className={cellL}>CAM (Contribuție Muncă - 2.25%)</td>
                    <td className={cellR}>{fmt(rezAfisat.rez.cam)}</td>
                  </tr>
                  <tr className="bg-slate-50">
                    <td className="px-3 py-2.5 text-left text-sm font-bold uppercase tracking-wide text-slate-700">COST TOTAL ANGAJATOR</td>
                    <td className="px-3 py-2.5 text-right text-sm font-bold tabular-nums text-slate-900">{fmt(rezAfisat.rez.costTotal)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          ) : (
            <div className="overflow-hidden rounded-lg border border-slate-200 text-slate-400" aria-label="Schelet fluturaș, neinițializat" data-md-strip>
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr>
                    <th className="border-b border-slate-300 bg-slate-100 px-3 py-2.5 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Indicator Fiscal</th>
                    <th className="border-b border-slate-300 bg-slate-100 px-3 py-2.5 text-right text-xs font-bold uppercase tracking-wide text-slate-500">Sumă</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className={cellL}>Salariu de încadrare (Brut)</td>
                    <td className={cellR} aria-hidden="true">—</td>
                  </tr>
                  <tr>
                    <td className={`${cellL} pl-8`}>CAS (Pensii - 25%)</td>
                    <td className={cellR} aria-hidden="true">—</td>
                  </tr>
                  <tr>
                    <td className={`${cellL} pl-8`}>CASS (Sănătate - 10%)</td>
                    <td className={cellR} aria-hidden="true">—</td>
                  </tr>
                  <tr>
                    <td className={cellL}>Impozit pe venit (10%)</td>
                    <td className={cellR} aria-hidden="true">—</td>
                  </tr>
                  <tr className="bg-slate-50">
                    <td className={`${cellL} font-semibold`}>Total Rețineri Angajat</td>
                    <td className={cellR} aria-hidden="true">—</td>
                  </tr>
                  <tr className="bg-emerald-600">
                    <td className="px-3 py-3 text-left text-sm font-bold uppercase tracking-wide text-white">SALARIU NET</td>
                    <td className="px-3 py-3 text-right text-base font-bold text-white/80" aria-hidden="true">—</td>
                  </tr>
                </tbody>
                <tbody>
                  <tr aria-hidden="true"><td colSpan={2} className="h-4 p-0" /></tr>
                </tbody>
                <tbody>
                  <tr>
                    <td className={cellL}>CAM (Contribuție Muncă - 2.25%)</td>
                    <td className={cellR} aria-hidden="true">—</td>
                  </tr>
                  <tr className="bg-slate-50">
                    <td className="px-3 py-2.5 text-left text-sm font-bold uppercase tracking-wide text-slate-700">COST TOTAL ANGAJATOR</td>
                    <td className="px-3 py-2.5 text-right text-sm font-bold" aria-hidden="true">—</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}

          {rezAfisat && (
            <button
              type="button"
              data-md-strip
              className="mt-6 inline-flex items-center gap-2 rounded-lg border border-slate-300 px-4 py-2.5 text-xs font-medium uppercase tracking-wide text-slate-700 transition-colors hover:border-emerald-600 hover:bg-emerald-600 hover:text-white"
              onClick={() => generarePDFFluturas(
                parseFloat(rezAfisat.brutEfectiv),
                rezAfisat.rez,
                parseFloat(rezAfisat.brutEfectiv) === SALARIU_MINIM && rezAfisat.functieDeBAza,
                DEDUCERE_MINIM
              )}
            >
              ↓ Descarcă fluturaș PDF
            </button>
          )}

          {!rezAfisat && (
            <p className="mt-4 text-xs uppercase leading-relaxed tracking-wide text-slate-400" data-md-strip>
              Completează salariul brut pentru a genera fluturașul · Grila fiscală 2026 (minim: 4.050 lei)
            </p>
          )}
        </div>
      </div>
    </>
  );
}