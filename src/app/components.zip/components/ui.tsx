// src/app/components/ui.tsx
// Primitive de layout + tipografie pentru paginile de conținut.
// Toate stilurile sunt utilitare Tailwind. <Prose> stilează automat
// elementele semantice (h2/h3/p/ul/a/strong) prin variante descendente,
// deci paginile scriu HTML curat, fără clase repetate.

import Link from "next/link";
import type { ReactNode } from "react";

const PROSE = [
  "[&_h2]:mt-10 [&_h2]:mb-4 [&_h2]:text-2xl [&_h2]:font-bold [&_h2]:tracking-tight [&_h2]:text-slate-900",
  "[&>h2:first-child]:mt-0",
  "[&_h3]:mt-6 [&_h3]:mb-2 [&_h3]:text-lg [&_h3]:font-semibold [&_h3]:text-slate-900",
  "[&_p]:mb-4 [&_p]:leading-relaxed [&_p]:text-slate-600",
  "[&_ul]:mb-4 [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:text-slate-600 [&_li]:mb-2 [&_li]:leading-relaxed",
  "[&_a]:font-medium [&_a]:text-emerald-700 [&_a]:underline [&_a]:underline-offset-2 hover:[&_a]:text-emerald-800",
  "[&_strong]:font-semibold [&_strong]:text-slate-900",
  "[&_em]:text-emerald-700",
  // Tabele: orice <table> semantic primește stilul fluturaș, fără clase
  "[&_table]:my-6 [&_table]:w-full [&_table]:border-collapse [&_table]:overflow-hidden [&_table]:rounded-lg [&_table]:border [&_table]:border-slate-200 [&_table]:text-sm",
  "[&_thead_th]:border-b [&_thead_th]:border-slate-300 [&_thead_th]:bg-slate-100 [&_thead_th]:px-3 [&_thead_th]:py-2.5 [&_thead_th]:text-left [&_thead_th]:text-xs [&_thead_th]:font-bold [&_thead_th]:uppercase [&_thead_th]:tracking-wide [&_thead_th]:text-slate-500",
  "[&_tbody_td]:border-b [&_tbody_td]:border-slate-100 [&_tbody_td]:px-3 [&_tbody_td]:py-2.5 [&_tbody_td]:text-slate-700",
  // .source-note (clasă cu specificitate 0,2,0) bate variantele de element 0,1,1
  "[&_.source-note]:mt-4 [&_.source-note]:text-xs [&_.source-note]:italic [&_.source-note]:leading-relaxed [&_.source-note]:text-slate-400",
].join(" ");

export function Prose({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`${PROSE} ${className}`}>{children}</div>;
}

export function Hero({ children }: { children: ReactNode }) {
  return (
    <section className="border-b border-slate-200 bg-slate-50 py-10 sm:py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">{children}</div>
    </section>
  );
}

export function Section({ children, wide = false }: { children: ReactNode; wide?: boolean }) {
  return (
    <section className="border-t border-slate-200 py-10 sm:py-12">
      <div className={`mx-auto px-4 sm:px-6 ${wide ? "max-w-6xl" : "max-w-3xl"}`}>
        <Prose>{children}</Prose>
      </div>
    </section>
  );
}

export function Breadcrumb({ items }: { items: { href?: string; label: string }[] }) {
  return (
    <nav className="mb-4 flex flex-wrap gap-2 text-xs uppercase tracking-wide text-slate-400" aria-label="Breadcrumb">
      {items.map((it, i) => (
        <span key={i} className="flex gap-2">
          {it.href ? (
            <Link href={it.href} className="hover:text-slate-700">{it.label}</Link>
          ) : (
            <span aria-current="page">{it.label}</span>
          )}
          {i < items.length - 1 && <span aria-hidden="true">/</span>}
        </span>
      ))}
    </nav>
  );
}

export function H1({ children }: { children: ReactNode }) {
  return (
    <h1 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl [&_em]:not-italic [&_em]:text-emerald-700">
      {children}
    </h1>
  );
}

export function Lead({ children }: { children: ReactNode }) {
  return (
    <p className="mt-3 max-w-2xl text-base leading-relaxed text-slate-600 [&_a]:font-medium [&_a]:text-emerald-700 [&_a]:underline [&_a]:underline-offset-2">
      {children}
    </p>
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="mt-4 text-xs uppercase tracking-wide text-slate-400">{children}</p>;
}

// Listă FAQ cu <details>/<summary> nativ. Marker custom +/− prin group-open.
export function Faq({
  items,
  title = "Întrebări frecvente",
}: {
  items: { q: string; a: string }[];
  title?: string;
}) {
  return (
    <section className="border-t border-slate-200 bg-slate-50 py-10 sm:py-12">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <h2 className="mb-6 text-2xl font-bold tracking-tight text-slate-900">{title}</h2>
        <div className="flex flex-col">
          {items.map((item, i) => (
            <details key={i} className="group border-b border-slate-200 py-4">
              <summary className="flex cursor-pointer items-center justify-between gap-4 text-base font-medium text-slate-900 [&::-webkit-details-marker]:hidden">
                {item.q}
                <span className="flex-shrink-0 text-xl text-emerald-600 group-open:hidden">+</span>
                <span className="hidden flex-shrink-0 text-xl text-emerald-600 group-open:inline">−</span>
              </summary>
              <p className="mt-3 leading-relaxed text-slate-600">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

// Card CTA final — titlu, paragraf, buton emerald.
export function CtaCard({
  title,
  children,
  href = "/",
  label,
}: {
  title: string;
  children: ReactNode;
  href?: string;
  label: string;
}) {
  return (
    <section className="border-t border-slate-200 py-10 sm:py-12">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-6 sm:p-8">
          <h2 className="mb-2 text-2xl font-bold tracking-tight text-slate-900">{title}</h2>
          <p className="mb-5 leading-relaxed text-slate-600">{children}</p>
          <Link
            href={href}
            className="inline-block rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-emerald-700"
          >
            {label}
          </Link>
        </div>
      </div>
    </section>
  );
}
